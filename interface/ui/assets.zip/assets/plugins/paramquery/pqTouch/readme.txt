Touch support for javascript controls with normal rendering as well as virtual rendering. 
Works by monkey patching jQueryUI mouse prototpye.
Inspired from touch-punch file by Dave Furfero which is great but lacks support for modern controls with virtual rendering.