/**
 * ParamQuery Pro
 * 
 * Copyright (c) 2012-2019 Paramvir Dhindsa (http://paramquery.com)
 * Released under Commercial license
 * http://paramquery.com/pro/license
 * 
 */     


ParamQuery Pro
++++++++++++++

Tutorial: http://paramquery.com/pro/tutorial

Demos: http://paramquery.com/pro/demos

API: http://paramquery.com/pro/api



Downloads: Product Updates can be downloaded from the forum 
	   once you sign up and let us upgrade your account.


FAQ: http://paramquery.com/pro/faq


Support 

	Forum: http://paramquery.com/forum

	Email: support@paramquery.com


Angularjs grid
++++++++++++++

http://angularjsgrid.com