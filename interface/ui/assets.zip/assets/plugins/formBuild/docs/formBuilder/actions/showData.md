# Actions -> showData
Show formBuilder data.

## Usage
```javascript
var fbEditor = document.getElementById('build-wrap');
var formBuilder = $(fbEditor).formBuilder();

document.getElementById('showData').addEventListener('click', function() {
    formBuilder.actions.showData()
});
```
## See it in Action
<p data-height="525" data-theme-id="22927" data-embed-version="2" data-slug-hash="GmovxN" data-default-tab="result" data-user="kevinchappell" class="codepen"></p>
